/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_order_itemmeta`; */
/* PRE_TABLE_NAME: `1707847097_wp_woocommerce_order_itemmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_woocommerce_order_itemmeta` ( `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT, `order_item_id` bigint unsigned NOT NULL, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_520_ci, PRIMARY KEY (`meta_id`), KEY `order_item_id` (`order_item_id`), KEY `meta_key` (`meta_key`(32))) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707847097_wp_woocommerce_order_itemmeta` (`meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES (1,1,'_product_id',17),(2,1,'_variation_id',0),(3,1,'_qty',1),(4,1,'_tax_class','gst-8'),(5,1,'_line_subtotal',12),(6,1,'_line_subtotal_tax',0),(7,1,'_line_total',12),(8,1,'_line_tax',0),(9,1,'_line_tax_data','a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}');
