/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_attribute_taxonomies`; */
/* PRE_TABLE_NAME: `1707847097_wp_woocommerce_attribute_taxonomies`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_woocommerce_attribute_taxonomies` ( `attribute_id` bigint unsigned NOT NULL AUTO_INCREMENT, `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL, `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL, `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL, `attribute_public` int NOT NULL DEFAULT '1', PRIMARY KEY (`attribute_id`), KEY `attribute_name` (`attribute_name`(20))) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707847097_wp_woocommerce_attribute_taxonomies` (`attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES (1,'color','color','color','menu_order',0),(2,'size','size','button','menu_order',1);
