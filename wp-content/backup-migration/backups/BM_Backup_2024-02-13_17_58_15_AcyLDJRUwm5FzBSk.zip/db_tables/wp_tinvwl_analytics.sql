/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_tinvwl_analytics`; */
/* PRE_TABLE_NAME: `1707847097_wp_tinvwl_analytics`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_tinvwl_analytics` ( `ID` varchar(32) NOT NULL, `wishlist_id` bigint NOT NULL DEFAULT '0', `product_id` bigint NOT NULL DEFAULT '0', `variation_id` bigint NOT NULL DEFAULT '0', `visite_author` bigint NOT NULL DEFAULT '0', `visite` bigint NOT NULL DEFAULT '0', `click_author` bigint NOT NULL DEFAULT '0', `click` bigint NOT NULL DEFAULT '0', `cart` bigint NOT NULL DEFAULT '0', `sell_of_wishlist` bigint NOT NULL DEFAULT '0', `sell_as_gift` bigint NOT NULL DEFAULT '0', PRIMARY KEY (`ID`), KEY `unique_product` (`wishlist_id`,`product_id`,`variation_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
INSERT INTO `1707847097_wp_tinvwl_analytics` (`ID`, `wishlist_id`, `product_id`, `variation_id`, `visite_author`, `visite`, `click_author`, `click`, `cart`, `sell_of_wishlist`, `sell_as_gift`) VALUES ('9a4743074940ccbba5c61380032c0fe6',1,24,29,1,0,0,0,1,0,0),('bfd94d7f6fc5371d4ac3372504190d28',2,17,0,1,0,0,0,2,0,0);
