/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1707847097_wp_wc_category_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_wc_category_lookup` ( `category_tree_id` bigint unsigned NOT NULL, `category_id` bigint unsigned NOT NULL, PRIMARY KEY (`category_tree_id`,`category_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707847097_wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES (15,15),(19,19),(34,34),(44,44),(49,49),(52,52),(54,54),(55,55);
