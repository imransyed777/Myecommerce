/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_orders_meta`; */
/* PRE_TABLE_NAME: `1707847097_wp_wc_orders_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_wc_orders_meta` ( `id` bigint unsigned NOT NULL AUTO_INCREMENT, `order_id` bigint unsigned DEFAULT NULL, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `meta_value` text COLLATE utf8mb4_unicode_520_ci, PRIMARY KEY (`id`), KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)), KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707847097_wp_wc_orders_meta` (`id`, `order_id`, `meta_key`, `meta_value`) VALUES (1,164,'_shipping_hash','9d4568c009d203ab10e33ea9953a0264'),(2,164,'_coupons_hash','d751713988987e9331980363e24189ce'),(3,164,'_fees_hash','d751713988987e9331980363e24189ce'),(4,164,'_taxes_hash','d751713988987e9331980363e24189ce'),(5,164,'is_vat_exempt','no'),(6,164,'_billing_address_index','imran sd  Highway Colony  Hyderabad TS 500074 IN syedimran998930@gmail.com +917993556144'),(7,164,'_shipping_address_index','imran sd  Highway Colony  Hyderabad TS 500074 IN +917993556144');
