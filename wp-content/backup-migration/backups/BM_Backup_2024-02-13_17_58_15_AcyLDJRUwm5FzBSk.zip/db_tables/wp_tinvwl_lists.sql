/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_tinvwl_lists`; */
/* PRE_TABLE_NAME: `1707847097_wp_tinvwl_lists`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_tinvwl_lists` ( `ID` bigint NOT NULL AUTO_INCREMENT, `author` bigint NOT NULL DEFAULT '0', `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `title` text, `status` varchar(20) NOT NULL DEFAULT 'public', `type` varchar(20) NOT NULL DEFAULT 'list', `share_key` varchar(45) NOT NULL, PRIMARY KEY (`ID`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
INSERT INTO `1707847097_wp_tinvwl_lists` (`ID`, `author`, `date`, `title`, `status`, `type`, `share_key`) VALUES (1,1,'2024-02-12 20:25:47','','share','default','51d435'),(2,0,'2024-02-13 17:57:49','My wishlist','share','default',869372);
