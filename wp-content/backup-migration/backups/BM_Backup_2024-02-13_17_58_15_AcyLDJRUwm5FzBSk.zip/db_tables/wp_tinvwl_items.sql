/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_tinvwl_items`; */
/* PRE_TABLE_NAME: `1707847097_wp_tinvwl_items`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707847097_wp_tinvwl_items` ( `ID` bigint NOT NULL AUTO_INCREMENT, `wishlist_id` bigint NOT NULL DEFAULT '0', `product_id` bigint NOT NULL DEFAULT '0', `variation_id` bigint NOT NULL DEFAULT '0', `formdata` text, `author` bigint NOT NULL DEFAULT '0', `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `quantity` bigint NOT NULL DEFAULT '1', `price` varchar(255) NOT NULL DEFAULT '0', `in_stock` tinyint(1) NOT NULL DEFAULT '1', PRIMARY KEY (`ID`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
INSERT INTO `1707847097_wp_tinvwl_items` (`ID`, `wishlist_id`, `product_id`, `variation_id`, `formdata`, `author`, `date`, `quantity`, `price`, `in_stock`) VALUES (1,1,24,29,'{\"attribute_pa_color\":\"black\",\"attribute_pa_size\":\"large\",\"tinvwl-hidden-fields\":\"[\\\"add-to-cart\\\",\\\"product_id\\\",\\\"variation_id\\\"]\"}',1,'2024-02-13 10:21:28',1,13,1);
